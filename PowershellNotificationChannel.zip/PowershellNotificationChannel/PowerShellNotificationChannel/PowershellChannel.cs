using B360.Notifier.Common;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Linq;

namespace B360.Notifier.PowerShellNotification
{
    // Note: "System.Runtime.Serialization" -- This Assembly need to be added as a reference to this Project.
    public class PowershellChannel : IChannelNotification
    {
        public string GetGlobalPropertiesSchema()
        {
            return Helper.GetResourceFileContent("GlobalProperties.xml");
        }

        public string GetAlarmPropertiesSchema()
        {
            return Helper.GetResourceFileContent("AlarmProperties.xml");
        }

        public bool SendNotification(BizTalkEnvironment environment, Alarm alarm, string globalProperties, Dictionary<MonitorGroupTypeName, MonitorGroupData> notifications)
        {
            try
            {   
                //Read configured properties
                var bsd = XNamespace.Get("http://www.biztalk360.com/alarms/notification/basetypes");

                var fileFolder = string.Empty; var folderOverride = string.Empty;

                //Alarm Properties
                var almProps = XDocument.Load(new StringReader(alarm.AlarmProperties));
                foreach (var element in almProps.Descendants(bsd + "TextBox"))
                {
                    var xAttribute = element.Attribute("Name");
                    if (xAttribute == null || xAttribute.Value != "file-override-path") continue;
                    var attribute = element.Attribute("Value");
                    if (attribute != null) folderOverride = attribute.Value;
                }

                //Global Properties
                var globalProps = XDocument.Load(new StringReader(globalProperties));
                foreach (var element in globalProps.Descendants(bsd + "TextBox"))
                {
                    var xAttribute = element.Attribute("Name");
                    if (xAttribute == null || xAttribute.Value != "file-path") continue;
                    var attribute = element.Attribute("Value");
                    if (attribute != null) fileFolder = attribute.Value;
                }

                // Get the File path with script name
                var filePath = string.IsNullOrEmpty(folderOverride) ? fileFolder : folderOverride;
                
                string psScript = string.Empty;
                if (File.Exists(filePath))
                    psScript = File.ReadAllText(filePath);
                else
                    throw new FileNotFoundException("Wrong path for the script file");
                RunspaceConfiguration config = RunspaceConfiguration.Create();
                //create powershell runspace
                Runspace cmdlet = RunspaceFactory.CreateRunspace(config);
                cmdlet.Open();
                RunspaceInvoke scriptInvoker = new RunspaceInvoke(cmdlet);
                // set powershell execution policy to unrestricted
                scriptInvoker.Invoke("Set-ExecutionPolicy Unrestricted");
                // create a pipeline and load it with command object
                Pipeline pipeline = cmdlet.CreatePipeline();
                try
                {
                    // Using Get-SPFarm powershell command 
                    pipeline.Commands.AddScript(psScript);
                    pipeline.Commands.AddScript("Out-String");
                    // this will format the output
                    Collection<PSObject> output = pipeline.Invoke();
                    pipeline.Stop();
                    cmdlet.Close();
                    // process each object in the output and append to stringbuilder  
                    StringBuilder results = new StringBuilder();
                    foreach (PSObject obj in output)
                    {
                        results.AppendLine(obj.ToString());
                    }
                    LoggingHelper.Info("Powershell notification completed successfully");
                    return true;
                }
                catch (Exception ps1ex)
                {
                    return false;
                }                
            }
            catch (Exception ex)
            {
                LoggingHelper.Info("Powershell notification failed. Error " + ex.Message);
                return false;
                // ignored
            }

        }
    }
}
